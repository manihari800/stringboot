package com.assignment.info;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
